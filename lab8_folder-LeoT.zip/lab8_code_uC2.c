
//M2
#define FREQ_CLK 1000000
#include <avr/io.h>

void initialize_usart(void);

void transmit_data_usart(unsigned char data);

unsigned char receive_data_usart(void);

void delayNms_timer0(volatile int number_of_msec);



int main(void)

{

	unsigned char received_data;
	unsigned char received_data1;
	unsigned char received_data2;

	
	DDRB = 0xFF; // Set PORTB (PB0-PB7) as output for LEDs
	PORTB = 0xFF;

	initialize_usart();

	received_data = receive_data_usart();
	received_data1 = receive_data_usart();
	received_data2 = receive_data_usart();

	PORTB = ~received_data; // Display received byte on LEDs (active low)
	received_data += 1;
	transmit_data_usart(received_data);

	delayNms_timer0(3000);
	

	PORTB = ~received_data1;
	received_data1 += 1;
	transmit_data_usart(received_data1);
	
	delayNms_timer0(3000);
	PORTB = ~received_data2;
	received_data2 += 1;
	transmit_data_usart(received_data2);
	
	delayNms_timer0(3000); // Final delay to ensure correct timing


}

void initialize_usart(void)

{

	UBRR0L = 0x28; // assuming 8 MHz clock)

	UCSR0B = (1 << RXEN0) | (1 << TXEN0); // Enable receiver and transmitter

	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00); // Asynchronous, 8-bit data, no parity, 1 stop bit

}



void transmit_data_usart(unsigned char data)
{
	while (!(UCSR0A & (1 << UDRE0))); // Wait until the transmit buffer is empty
	UDR0 = data;
}


unsigned char receive_data_usart(void)
{
	while (!(UCSR0A & (1 << RXC0))); // Wait for data to be received
	return UDR0;
}



// Custom delay function based on Timer0

void delayNms_timer0(volatile int number_of_msec)

{

	char register_B_setting;
	char count_limit;
	
	// Some typical clock frequencies:
	switch(FREQ_CLK) {
		case 16000000:
		register_B_setting = 0b00000011; // this will start the timer in Normal mode with prescaler of 64 (CS02 = 0, CS01 = CS00 = 1).
		count_limit = 250; // For prescaler of 64, a count of 250 will require 1 msec
		break;
		case 8000000:
		register_B_setting =  0b00000011; // this will start the timer in Normal mode with prescaler of 64 (CS02 = 0, CS01 = CS00 = 1).
		count_limit = 125; // for prescaler of 64, a count of 125 will require 1 msec
		break;
		case 1000000:
		register_B_setting = 0b00000010; // this will start the timer in Normal mode with prescaler of 8 (CS02 = 0, CS01 = 1, CS00 = 0).
		count_limit = 125; // for prescaler of 8, a count of 125 will require 1 msec
		break;
	}
	
	while (number_of_msec > 0) {
		TCCR1A = 0x00; // clears WGM00 and WGM01 (bits 0 and 1) to ensure Timer/Counter is in normal mode.
		TCNT1 = 0;  // preload value for testing on count = 250
		TCCR1B =  register_B_setting;  // Start TIMER0 with the settings defined above
		while (TCNT1 < count_limit); // exits when count = the required limit for a 1 msec delay
		TCCR1B = 0x00; // Stop TIMER0
		number_of_msec--;
	}
}