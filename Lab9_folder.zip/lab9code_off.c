

#include <avr/io.h>

//Function Declarations 
void spi_init(void);
void spi_send(uint8_t data);
void max7221_write(uint8_t address, uint8_t data);
void max7221_init(void);
void display_date(void);
void wait_with_timer1(volatile int number_of_msec);

#define SS PB2
#define MOSI PB3
#define SCK PB5
#define FREQ_CLK 16000000  // Define clock frequency

int main() {
	// SPI Setup
	DDRB |= (1 << SS) | (1 << MOSI) | (1 << SCK);  // Set SS, MOSI, SCK as output
	spi_init();
	max7221_init();

	while (1) {
		display_date();  // Continuously display the date
	}
}


//SPI Initialization Function
//Sets up the ATmega328P SPI as Master

void spi_init(void) {
	SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR0); // Enable SPI, Master mode, clock rate fck/16
}


//SPI Send Function
//Sends one byte of data over SPI

void spi_send(uint8_t data) {
	SPDR = data;
	while (!(SPSR & (1 << SPIF))); // Wait for transmission complete
}


//MAX7221 Write Function
//Sends an address and data byte to the MAX7221 over SPI

void max7221_write(uint8_t address, uint8_t data) {
	PORTB &= ~(1 << SS);  // Select MAX7221
	spi_send(address);
	spi_send(data);
	PORTB |= (1 << SS);   // Deselect MAX7221
}


//MAX7221 Initialization Function
//Configures the MAX7221 settings

void max7221_init(void) {
	max7221_write(0x09, 0xFF); // Decode mode: BCD for all digits
	max7221_write(0x0A, 0x08); // Intensity: Medium
	max7221_write(0x0B, 0x02); // Scan limit: 2 digits
	max7221_write(0x0C, 0x01); // Shutdown mode: Normal operation
	max7221_write(0x0F, 0x00); // Display test: Off
}

 
//Display Date Function
//Displays "03" for March, then "26" for the day, followed by a blank screen

void display_date(void) {
	// Display month "03" (0x03 for '3', 0x0 for '0')
	max7221_write(0x02, 0x03);  // '3' on the right display (2nd digit)
	max7221_write(0x01, 0x0);   // '0' on the left display (1st digit)
	wait_with_timer1(1000);      // Wait for 1 second

	// Display day "26" (0x06 for '6', 0x02 for '2')
	max7221_write(0x02, 0x06);  // '6' on the right display (2nd digit)
	max7221_write(0x01, 0x02);  // '2' on the left display (1st digit)
	wait_with_timer1(1000);      // Wait for 1 second

	// Blank display for 2 seconds
	max7221_write(0x01, 0x0F);  // Blank display (All segments off)
	max7221_write(0x02, 0x0F);  // Blank display (All segments off)
	wait_with_timer1(2000);      // Wait for 2 seconds
}


//Wait Function using Timer1
//Creates a delay using Timer1 for precise timing

void wait_with_timer1(volatile int number_of_msec) {
	char register_B_setting;
	char count_limit;

	// Select appropriate Timer1 settings based on clock frequency
	switch(FREQ_CLK) {
		case 16000000:
			register_B_setting = 0b00000011; // Prescaler = 64
			count_limit = 250;
			break;
		case 8000000:
			register_B_setting = 0b00000011; // Prescaler = 64
			count_limit = 125;
			break;
		case 1000000:
			register_B_setting = 0b00000010; // Prescaler = 8
			count_limit = 125;
			break;
	}

	while (number_of_msec > 0) {
		TCCR1A = 0x00;  // Normal mode
		TCNT1 = 0;  // Reset counter
		TCCR1B = register_B_setting;  // Start timer
		while (TCNT1 < count_limit); // Wait for count to reach limit
		TCCR1B = 0x00;  // Stop timer
		number_of_msec--;
	}
}
