#include <avr/io.h>
#include <avr/interrupt.h>

#define FREQ_CLK 8000000 // Clock frequency

//** GLOBAL VARIABLES **/
volatile int led6_on = 0;//off
volatile int led7_on = 0;// off
volatile int debounce = 50; // 50ms debounce time
volatile int led_position = 0; // Ensure led_position is global

void wait_with_timer1(volatile int number_of_msec);  // wait function

int main(void) //main tasks
{
	DDRC = 0b00111111; // Set PORTC for scrolling LEDs (PC0-PC5 as output, active-low-0-on-1-off)
	
	DDRB = 0b00000011;// Set PORTB for LED 6 and LED 7 (PB0, PB1 as output, active-low)
	
	DDRD &= ~(0b00001100); // Set PD2 and PD3 as input for switches
	
	PORTD |= 0b00001100; // Enable pull-up resistors on PD2 and PD3 (so switches are high when not pressed)

	PORTB |= 0b00000011; // Ensure LED 6 and 7 are OFF initially (active-low)
	
	PORTC = 0b11111111; // Ensure all scrolling LEDs are OFF initially (active-low logic)

	// Set up Interrupts (falling edge detection)
	EICRA = (1 << ISC01) | (0 << ISC00) | (1 << ISC11) | (0 << ISC10); // Falling edge triggers INT0, INT1
	EIMSK = (1 << INT0) | (1 << INT1); // Enable INT0 and INT1
	sei(); // Enable global interrupts

	int led_pattern[] = {0b11111110, 0b11111101, 0b11111011, 0b11110111, 0b11101111, 0b11011111}; // Active-low LED sequence

	while (1) // Main loop for LED scrolling, keep repeating
	{
		if (!led6_on && !led7_on) // If LED 6 and 7 are OFF, the full led pattern will go
		{
			PORTC = led_pattern[led_position]; // Light up current LED {led_position=0)
			wait_with_timer1(500); // Wait 500ms between transitions
			led_position = (led_position + 1) % 6; // +1 Move to next LED in array, %6 restart at 0 after reaching index 5
		}
		else if (led6_on && !led7_on) // If LED 6 is ON and LED 7 is OFF
		{
									// Only LED3-LED5
			int led_sub_pattern[] = {0b11110111, 0b11101111, 0b11011111}; // Active-low for PC3-PC5
			for (int i = 0; i < 3; i++)  
			{
				PORTC = led_sub_pattern[i]; // Instantly move to the next LED
				wait_with_timer1(500); // Wait 500ms between transitions
			}
		}
	}

	return 0;
}

//** INTERRUPT SERVICE ROUTINES **/
ISR(INT0_vect)
{
	wait_with_timer1(debounce); // Debounce the switch

	if ((PORTC & 0b00000100) == 0 && !led6_on) // Check if LED 2 (PC2) is ON (active-low), led 6 off
	{
		PORTB &= 0b11111110; // Turn on LED 6 (active-low)
		led6_on = 1; // led 6 is on
	}

	EIFR = 0b00000001; // Clear INT0 flag to allow new interrupt
}

ISR(INT1_vect)
{
	wait_with_timer1(debounce); // Debounce the switch

	if (led6_on && !(PORTC & 0b00100000) && !led7_on) // Check if LED 5 (PC5) is ON, LED 6 already on, LED 7 off
	{
		PORTB &= 0b11111101; // Turn ON LED 7 (Active-low)
		led7_on = 1; // LED 7 is on
		PORTC |= 0b00100000; // Turn OFF LED 5

		wait_with_timer1(3000); // Wait for 3 seconds

		// **RESET ALL LEDs & RESTART FULL PATTERN**
		PORTB |= 0b00000011; // Turn OFF LED 7 & LED 6
		PORTC = 0b11111111;  // Ensure all LEDs are OFF before restarting

		// Reset flags
		led6_on = 0;
		led7_on = 0;
		led_position = 0;
	}

	EIFR = 0b00000010; // Clear INT1 flag
}

// Wait function using Timer1 for a delay in milliseconds
void wait_with_timer1(volatile int number_of_msec)
{
	char register_B_setting;
	char count_limit;
	
	// Set up based on clock frequency
	switch(FREQ_CLK) {
		case 16000000:
		register_B_setting = 0b00000011; // prescaler 64
		count_limit = 250;
		break;
		case 8000000:
		register_B_setting = 0b00000011; // prescaler 64
		count_limit = 125;
		break;
		case 1000000:
		register_B_setting = 0b00000010; // prescaler 8
		count_limit = 125;
		break;
	}
	
	while (number_of_msec > 0) {
		TCCR1A = 0x00; // Clear WGM00 and WGM01 (bits 0 and 1) to normal mode
		TCNT1 = 0;  // Reset timer
		TCCR1B =  register_B_setting;  // Start Timer1 with the correct settings
		while (TCNT1 < count_limit); // Wait for the timer to reach count limit
		TCCR1B = 0x00; // Stop Timer1
		number_of_msec--;
	}
}
