/* 

 * Lab 3 - Timing and Delays with ATmega328P 

 *  

 * LED Blink Pattern with Pause/Resume  

 * 

 * Author: Thuc Tran

 */ 

 

#include <avr/io.h> 

 

#define FREQ_CLK 1000000 // Clock frequency (default setting for the ATmega328P -- 8 MHz internal clock with divide-by-8


 
// ** Function Declarations ** 

void wait(volatile int multiple); 

void change_LED_state(char); 

 

// ** Main Program ** 

int main(void) 

{ 

    // Setup

    int number_of_states = 22; // number of leds petterns + 2 second offs

    char pattern[] = {'A','C','B','C','A','C','A','D','A','D','B','C','B','C','A','D','B','C','B','C','B','E'}; //Array contains the states pf the LeDs in the on-off pattern

 

    DDRC = 0b00000011;  // Set PC0 & PC1 as output (for 2 LEDs) 

    PORTC = 0b00000011; // Start with LEDs OFF (Active Low) 

 

    DDRD =0b00000000; // Set PD2 as input (Button) 
while(PIND & 0b00000100) // this logic causes the program to stay in the loop if pim PD2 is high(switch is not pressed)
{
}

  

    // Main Loop (Run Pattern Repeatedly)

    while (1) { //repeatedly display the Led patterns 

        for (int i = 0; i < number_of_states; i++) {   //scroll through the led patterns states

            change_LED_state(pattern[i]);  // pass the current pattern state to the function to change to a new state

        } 

    } 

 

    return 0; 

} 

 

// **Change LED State Based on Pattern** 

void change_LED_state(char new_state) {  // this function chnages the ;ed states into a new state defined by the passed argurment (new state (A=C=200msec;, B=D=600msec), default or E=2000msec

    switch (new_state) { 

        case 'A':  // short on period

            PORTC = 0b00000000; // Both LEDs ON (Active Low) 

            wait(200);  

            break; 

        case 'B':  //long on period

            PORTC = 0b00000000; // Both LEDs ON 

            wait(600);  

            break; 

        case 'C': //short off period

            PORTC = 0b00000011; // Both LEDs OFF 

            wait(200); 

            break; 

        case 'D': //long off period

            PORTC = 0b00000011; // Both LEDs OFF 

            wait(600); 

            break; 

        default:  // 2 second off period before repeating pattern

            PORTC = 0b00000011; // Turn OFF both LEDs 

            wait(2000); 

    } 

 
    // **Pause Execution if Button is Pressed** 

    while (!(PIND & 0b00000100)) {  

        wait(50);  // Short delay to prevent fast bouncing 

    } 

} // end change led state

 

// **5. Timer-Based Delay Function (Replaces _delay_ms)** 

void wait(volatile int number_of_msec) { 
	// This subroutine creates a delay equal to number_of_msec*T, where T is 1 msec
	// It changes depending on the frequency defined by FREQ_CLK

    char register_B_setting; 

    char count_limit; 

 

    // ** Select Timer Settings Based on Frequency ** 

    switch(FREQ_CLK) { 

        case 16000000: 

            register_B_setting = 0b00000011; // this will start the timer in Normal mode with prescaler of 64 (CS02 = 0, CS01 = CS00 = 1).


            count_limit = 250;  // For prescaler of 64, a count of 250 will require 1 msec

            break; 

        case 8000000: 

            register_B_setting = 0b00000011; // this will start the timer in Normal mode with prescaler of 64 (CS02 = 0, CS01 = CS00 = 1). 
            count_limit = 125;  // for prescaler of 64, a count of 125 will require 1 msec

            break; 

        case 1000000: 

            register_B_setting = 0b00000010; // this will start the timer in Normal mode with prescaler of 8 (CS02 = 0, CS01 = 1, CS00 = 0). 

            count_limit = 125;  // for prescaler of 8, a count of 125 will require 1 msec
            break; 

    } 

 

    while (number_of_msec > 0) { 

        TCCR0A = 0x00; // clears WGM00 and WGM01 (bits 0 and 1) to ensure Timer/Counter is in normal mode.

        TCNT0 = 0; // Reset counter, preload value for testing on count = 250

        TCCR0B = register_B_setting; //Start TIMER0 with the settings defined above

        while (TCNT0 < count_limit); // exits when count = the required limit for a 1 msec delay

        TCCR0B = 0x00; // Stop TIMER0 

        number_of_msec--; 

 
	}
     
} // end wait()

 