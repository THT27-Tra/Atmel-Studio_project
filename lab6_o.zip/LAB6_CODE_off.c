#include <avr/io.h>

char sensorvalue = 0;

int main(void) {
	// **SETUP_LEDS**
	DDRC = 0b00011111;  // PC0-PC4 as OUTPUT (LEDs), PC5 as INPUT (ADC)
	PORTC = 0b00011111; // Turn off all LEDs initially (active-low)
	
	// **SETUP ADC**
	PRR = 0b00000000;    // Ensure ADC is powered
	ADMUX  = 0b01100101; // AVcc as reference, Left-adjust, Select ADC5 (PC5)
	ADCSRA = 0b10000111; // Enable ADC, Prescaler = 128
	
	// **SETUP PWM & MOTOR CONTROL PINS**
	DDRD |= 0b01000011;  // PD6 (PWM), PD0 & PD1 (Direction)
	DDRD |= 0b01000000;  // Ensure PD6 (OC0A) is an output
	
	TCCR0A = 0b10000011; // Fast PWM, non-inverting mode
	TCCR0B = 0b00000011; // Prescaler 64 (~1kHz PWM frequency)
	
	OCR0A = 0;           // Start with motor off
	PORTD &= 0b11111100; // Motor stopped PD0 AND PD1
	
	while (1) {
		// **START ADC CONVERSION**
		ADCSRA |= 0b01000000;
		while ((ADCSRA & 0b00010000) == 0); // Wait for ADC to finish
		sensorvalue = ADCH; // Read 8-bit ADC result
		
		// **RESET LEDs**
		PORTC = 0b00011111; // Turn off all LEDs
		
		// **LINEAR MAPPING OF ADC TO 50% MAX DUTY CYCLE**
		int duty_cycle = ((sensorvalue - 128) * 127) / 128; // Scale to -127 to +127 50%
		
		if (sensorvalue < 128) { // Backward motion
			PORTD &= 0b11111110; // PD0 = 0 (Forward OFF)
			PORTD |= 0b00000010; // PD1 = 1 (Reverse ON)
			OCR0A = -duty_cycle; // Convert negative values to positive for PWM
			} else { // Forward motion
			PORTD |= 0b00000001;  // PD0 = 1 (Forward ON)
			PORTD &= 0b11111101;  // PD1 = 0 (Reverse OFF)
			OCR0A = duty_cycle; // Use direct linear mapping
		}
		
		// **SET LED INDICATORS BASED ON ADC VALUE**
		if (sensorvalue < 54) 
			PORTC &= 0b11111110; // PC0 ON (Fast Backward)
		else if (sensorvalue < 98) 
			PORTC &= 0b11111101; // PC1 ON (Slow Backward)
		else if (sensorvalue < 152)
			 PORTC &= 0b11111011; // PC2 ON (Stopped)
		else if (sensorvalue < 206) 
			PORTC &= 0b11110111; // PC3 ON (Slow Forward)
		else 
			PORTC &= 0b11101111; // PC4 ON (Fast Forward)
	}
}
