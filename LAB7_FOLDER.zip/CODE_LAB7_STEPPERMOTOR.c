#include <avr/io.h>

#define FREQ_CLK 8000000 // Clock frequency

// Functions for Stepper Motor
void step_CW(void);
void step_CCW(void);
void wait(volatile int time_ms); 
void delay_T_msec_timer1(void); 

// Global variable for the phase of the stepper motor
int phase_step = 1;

int main(void) {
	// Configure I/O:
	DDRD = 0b11110000;  // PD4-PD7 as outputs for stepper motor control
	DDRB = 0b00000011;  // PB0 and PB1 as outputs for LED indication
	DDRC = 0b11111110;  // PC0 as input for the switch

	// Initialize PORTB with both LED bits high (LEDs off, active low)
	PORTB = 0b00000011;

	// Enable pull-up resistor on PC0 (switch input)
	PORTC = 0b00000001;

	while (1) {
		// Wait until the switch is pressed (active low)
		while (PINC & 0b00000001); // The program waits until PC0 is LOW (switch pressed).

		// Move 270� Clockwise (CW) in 2 seconds (36 steps)
		PORTB &= 0b11111101; // Turn ON CW LED
		for (int i = 0; i < 36; i++) {
			step_CW();
			wait(55);  // Adjusted timing for 2s total, 2s/36steps = 0.055s
		}
		PORTB |= 0b00000010; // Turn OFF CW LED
		wait(500);

		// Move 90� Counterclockwise (CCW) in 1 second (12 steps)
		PORTB &= 0b11111110; // Turn ON CCW LED
		for (int i = 0; i < 12; i++) {
			step_CCW();
			wait(83);  // Adjusted timing for 1s total 1s/12=0.083s
		}
		PORTB |= 0b00000001; // Turn OFF CCW LED
		wait(500);

		// Move 180� Clockwise (CW) in 2 seconds (24 steps)
		PORTB &= 0b11111101; // Turn ON CW LED
		for (int i = 0; i < 24; i++) {
			step_CW();
			wait(83);  // Adjusted timing for 2s total, 2s/24 = 0.083s
		}
		PORTB |= 0b00000010; // Turn OFF CW LED

		// Ensure both LEDs are off before waiting for the switch again
		PORTB |= 0b00000011;
	}
}
// Stepper motor control functions
// phase1a = PORTD_7, phase1b = PORTD_6
// phase2a = PORTD_5, phase2b = PORTD_4
// Stepper motor control functions
void step_CW(void) {//(PD5)-(PD6)-(PD4)- (PD7)-Repeat
	switch (phase_step) {
		case 1:
		PORTD = 0b00100000;  // PD5
		phase_step = 4;          // After phase 1, move to phase 4 OR Case 4 in the code
		break;
		case 2:
		PORTD = 0b10000000;  // PD7
		phase_step = 1;       // After phase 2, move to phase 1 OR Case 1 in the code
		break;
		case 3:
		PORTD = 0b00010000;  // PD4
		phase_step = 2;       // After phase 3, move to phase 2 OR Case 2 in the code
		break;
		case 4:
		PORTD = 0b01000000;  // PD6
		phase_step = 3;       // After phase 4, move to phase 3 OR Case 3 in the code
		break;
	}
}

void step_CCW(void) {
	switch (phase_step) {
		case 1:
		PORTD = 0b00010000;  // PD4
		phase_step = 2; // After phase 1, move to phase 2
		break;
		case 2:
		PORTD = 0b01000000; // PD6
		phase_step = 3;      // After phase 2, move to phase 3
		break;
		case 3:
		PORTD = 0b00100000;  // PD5
		phase_step = 4;      // After phase 3, move to phase 4
		break;
		case 4:
		PORTD = 0b10000000; // PD7
		phase_step = 1;      // After phase 4, move to phase 1
		break;
	}
}

// Modified wait function using Timer1 (one argument)
void wait(volatile int time_ms) {
	while (time_ms--) {
		delay_T_msec_timer1();  // Delay in milliseconds
	}
}

// Modified delay function using Timer1 for time in milliseconds
void delay_T_msec_timer1(void) {
	char register_B_setting;
	char count_limit;

	// Set up based on clock frequency
	switch(FREQ_CLK) {
		case 16000000:
		register_B_setting = 0b00000011; // prescaler 64
		count_limit = 250;
		break;
		case 8000000:
		register_B_setting = 0b00000011; // prescaler 64
		count_limit = 125;
		break;
		case 1000000:
		register_B_setting = 0b00000010; // prescaler 8
		count_limit = 125;
		break;
	}

	// Main loop for delay
	TCCR1A = 0x00; // Clear WGM00 and WGM01 (bits 0 and 1) to normal mode
	TCNT1 = 0;  // Reset timer
	TCCR1B = register_B_setting;  // Start Timer1 with the correct settings
	while (TCNT1 < count_limit); // Wait for the timer to reach count limit
	TCCR1B = 0x00; // Stop Timer1
}

