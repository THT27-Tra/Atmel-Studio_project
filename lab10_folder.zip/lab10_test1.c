#include <avr/io.h>

// Function Declarations
void spi_init(void);                // 1
void spi_send(uint8_t data);        // 2
void max7221_write(uint8_t address, uint8_t data); // 3
void max7221_init(void);            // 4
void display_temperature(int temp); // 5
void i2c_init(void);                // 6
void i2c_start(void);               // 7
void i2c_stop(void);                // 8
void i2c_write(uint8_t data);       // 9
uint8_t i2c_read_ack(void);         // 10
uint8_t i2c_read_nack(void);        // 11
int read_temperature(void);         // 12
void wait_with_timer1(volatile int number_of_msec); // 13

#define SS PB2
#define MOSI PB3
#define SCK PB5
#define SDA PC4
#define SCL PC5
#define MCP9808_ADDR 0x18 //MCP9808 has the 7-bit address
#define FREQ_CLK 16000000

int main() {
	// 1. SPI Setup
	DDRB |= (1 << SS) | (1 << MOSI) | (1 << SCK);  // Set SS, MOSI, SCK as output
	spi_init();                                 // 2. Initialize SPI
	max7221_init();                             // 3. Initialize MAX7221
	i2c_init();                                 // 4. Initialize I2C

	while (1) {
		// 5. Main Loop: Read and display temperature
		int temp = read_temperature();      // 6. Read temperature from MCP9808
		display_temperature(temp);          // 7. Display the temperature on MAX7221
		wait_with_timer1(1000);             // 8. Wait for 1 second (1000 ms) before refreshing
	}
}

// SPI Initialization Function
// 1. Sets up the ATmega328P SPI as Master
void spi_init(void) {
	SPCR = (1 << SPE) | (1 << MSTR) | (1 << SPR0); // Enable SPI, Master mode, fck/16
}

// SPI Send Function
// 2. Sends one byte of data over SPI
void spi_send(uint8_t data) {
	SPDR = data;
	while (!(SPSR & (1 << SPIF))); // Wait for transmission complete
}

// MAX7221 Write Function
// 3. Sends an address and data byte to the MAX7221 over SPI
void max7221_write(uint8_t address, uint8_t data) {
	PORTB &= ~(1 << SS); // Select MAX7221
	spi_send(address);    // Send address byte
	spi_send(data);       // Send data byte
	PORTB |= (1 << SS);   // deSelect MAX7221
}

// MAX7221 Initialization Function
// 4. Configures the MAX7221 settings
void max7221_init(void) {
	max7221_write(0x09, 0xFF); // Decode mode: BCD for all digits
	max7221_write(0x0A, 0x08); // Intensity: Medium
	max7221_write(0x0B, 0x02); // Scan limit: 2 digits
	max7221_write(0x0C, 0x01); // Shutdown mode: Normal operation
	max7221_write(0x0F, 0x00); // Display test: Off
}

// Display Temperature on MAX7221
// 5. Displays the temperature on the 7-segment display
void display_temperature(int temp) {
	int tens = (temp / 10) % 10;   // Get tens digit
	int ones = temp % 10;          // Get ones digit
	max7221_write(0x02, ones);     // Display ones digit
	max7221_write(0x01, tens);     // Display tens digit
}

// I2C Initialization Function
// 6. Initializes the I2C interface
void i2c_init(void) {
	TWSR = 0x00;    // No prescaler
	TWBR = 72;      // Set bit rate register for 100kHz SCL
	TWCR = (1 << TWEN); // Enable I2C
}

// I2C Start Function
// 7. Sends the I2C start condition
void i2c_start(void) {
	TWCR = (1 << TWSTA) | (1 << TWEN) | (1 << TWINT);  // Start condition
	while (!(TWCR & (1 << TWINT)));  // Wait for transmission to complete
}

// I2C Stop Function
// 8. Sends the I2C stop condition
void i2c_stop(void) {
	TWCR = (1 << TWSTO) | (1 << TWEN) | (1 << TWINT);  // Stop condition
}

// I2C Write Function
// 9. Sends one byte of data over I2C
void i2c_write(uint8_t data) {
	TWDR = data;                // Load data to be transmitted
	TWCR = (1 << TWEN) | (1 << TWINT); // Enable transmission
	while (!(TWCR & (1 << TWINT))); // Wait for transmission to complete
}

// I2C Read with Acknowledge
// 10. Reads a byte of data and sends ACK
uint8_t i2c_read_ack(void) {
	TWCR = (1 << TWEN) | (1 << TWINT) | (1 << TWEA); // Enable ACK
	while (!(TWCR & (1 << TWINT)));  // Wait for reception to complete
	return TWDR; // Return received byte
}

// I2C Read with No Acknowledge
// 11. Reads a byte of data and sends NACK
uint8_t i2c_read_nack(void) {
	TWCR = (1 << TWEN) | (1 << TWINT); // Disable ACK
	while (!(TWCR & (1 << TWINT)));   // Wait for reception to complete
	return TWDR; // Return received byte
}

// Read Temperature from MCP9808
// 12. Reads the temperature from MCP9808 sensor and returns Fahrenheit
int read_temperature(void) {
	i2c_start();                          // Start I2C communication
	i2c_write((MCP9808_ADDR << 1));       // Send address of MCP9808 for writing
	i2c_write(0x05);                      // Request temperature register
	i2c_start();                          // Restart for reading
	i2c_write((MCP9808_ADDR << 1) | 1);   // Send address for reading
	uint8_t upper_byte = i2c_read_ack();  // Read upper byte with ACK
	uint8_t lower_byte = i2c_read_nack(); // Read lower byte with NACK
	i2c_stop();                           // Stop I2C communication
	
	// Clear flag bits and extract temperature
	upper_byte = upper_byte & 0x1F;
	int temp;
	if ((upper_byte & 0x10) == 0x10) { // Negative temperature
		upper_byte = upper_byte & 0x0F;
		temp = 256 - (upper_byte * 16 + lower_byte / 16);
		} else { // Positive temperature
		temp = (upper_byte * 16 + lower_byte / 16);
	}
	return (temp * 9 / 5) + 32;  // Convert to Fahrenheit
}

// Wait Function with Timer1
// 13. Waits for the specified number of milliseconds
void wait_with_timer1(volatile int number_of_msec) {
	char register_B_setting;
	char count_limit;
	switch(FREQ_CLK) {
		case 16000000:
		register_B_setting = 0b00000011;
		count_limit = 250;
		break;
		case 8000000:
		register_B_setting = 0b00000011;
		count_limit = 125;
		break;
		case 1000000:
		register_B_setting = 0b00000010;
		count_limit = 125;
		break;
	}
	while (number_of_msec > 0) {
		TCCR1A = 0x00;
		TCNT1 = 0;
		TCCR1B = register_B_setting;
		while (TCNT1 < count_limit); // Wait for timer to overflow
		TCCR1B = 0x00;
		number_of_msec--; // Decrement the counter
	}
}

