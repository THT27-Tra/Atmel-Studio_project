#include <avr/io.h>
char  sensorvalue = 0;
int main(void) {
	// **SETUP**
  	DDRC = 0b00011111;  // PC0-PC4 as OUTPUT (LEDs), PC5 as INPUT (ADC)
	PORTC = 0b00011111; // Turn off all LEDs initially (active-low)

	// **SETUP ADC**
	PRR = 0b00000000;    // Ensure ADC is powered,clear Power Reduction ADC bit (0) in PRR register
	ADMUX  = 0b01100101; // AVcc as reference, Left-adjust, Select ADC5 (PC5)
	ADCSRA = 0b10000111; // Enable ADC, Prescaler = 128

	while (1) {
		// **START ADC CONVERSION**
		ADCSRA |= 0b01000000; // Start conversion
		while ((ADCSRA & 0b00010000) == 0); // Wait for conversion to finish

		// **READ ADC HIGH BYTE (8-bit left-adjusted)**
 		sensorvalue = ADCH;

		// **RESET LEDs (Active-Low Logic)**
		PORTC = 0b00011111; // Turn OFF all LEDs

		// **DETERMINE LED OUTPUT BASED ON ADC VALUE**
 		if (sensorvalue < 54) {  // ADC < 54 (Fast Backward)
			PORTC &= 0b11111110; // Turn ON PC0
		}
		else if (sensorvalue < 98) { // ADC < 98 (Slow Backward)
			PORTC &= 0b11111101; // Turn ON PC1
		}
		else if (sensorvalue < 152) { // ADC < 152 (Stopped)
			PORTC &= 0b11111011; // Turn ON PC2
		}
		else if (sensorvalue < 206) { // ADC < 206 (Slow Forward)
			PORTC &= 0b11110111; // Turn ON PC3
		}
		else { // ADC >= 206 (Fast Forward)
			PORTC &= 0b11101111; // Turn ON PC4
		}
	} // end while
} // end main

